<?php
//ini_set('display_errors', '0');
echo "<pre>";
	print_r($_REQUEST);
echo "</pre>";
?>
<?php
/*
	
	RewriteEngine on
	#RewriteBase    /vinix/
	#ErrorDocument    /vinix/

	Options All -Indexes
	RewriteCond %{REQUEST_FILENAME} !-f
	RewriteCond %{REQUEST_FILENAME} !-d

	RewriteRule ^nl/([^/]*)$ index.php?files=$1	
	RewriteRule ^nl/([^/]*)/([^/]*)/([^/]*)$ index.php?files=$1&catname=$2&catid=$3
	RewriteRule ^nl/([^/]*)/([^/]*)$ index.php?files=$1&subpage=$2
	RewriteRule ^nl/([^/]*)/([^/]*)/([^/]*)/([^/]*)/([^/]*)/([^/]*)$ index.php?files=$1&newsname=$5&newsid=$6


*/
?>
